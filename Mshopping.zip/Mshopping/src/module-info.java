/**
 * 
 */
/**
 * 
 */
module Mshopping {
}